library(shiny)
source("googleDocModule.R")
#----------------------------------------------------------------------------------------------------
ui <- fluidPage(
        selectInput("entitySelector", "Topic:", c("", "rs6857", "Myc", "APOE", "bogus")),
         div(googleDocUI(id="googleDoc", title="fubar"),
           style="margin: 10px; margin-bottom: 30px; padding: 10px;"),
        )

#----------------------------------------------------------------------------------------------------
server <- function(input, output, session)
{
   doc.base <- "https://docs.google.com/document"
   doc.tail <- "d/1Qwj9-vj8Q7b0GWLCs5UmHirQqGkejMex5w11E-CXLvU/edit?usp=sharing"
   doc.uri <- sprintf("%s/%s", doc.base, doc.tail)

  observeEvent(input$entitySelector, ignoreInit=TRUE, {
     entity <- input$entitySelector
       # eventually: branch on entitiy to different google docs
     if(!is.null(entity) && nchar(entity) > 0)
        callModule(googleDocServer, "googleDoc",  url=reactive(doc.uri))
     })

} # server
#----------------------------------------------------------------------------------------------------
runApp(shinyApp(ui, server), port=9071)
